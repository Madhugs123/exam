from ems import views
from django.urls import path
urlpatterns=[
    path('user/',views.user,name='ggc1'),
    path('login/',views.login,name='ggc2'),
    path('ems/',views.index,name='ggc'),
    path('sign/',views.signup,name="signup"),
    path('add-emp/',views.add,name='add'),
    path('view-emp/',views.view,name="view"),
    path('list-emp/',views.list,name='list'),
    path('dadd/',views.dadd,name='list3'),
    path('ld/',views.dlist,name='list4'),
    path('dfill/',views.dfilt,name='list5'),
    path('dfil1/',views.dfilt1,name='list6'),
    path('delete/<int:eid>',views.delete,name='list9'),
    path('user1/',views.func2,name='django'),


]

    
    