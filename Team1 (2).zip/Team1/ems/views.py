from django.shortcuts import render,redirect
from .models import *
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q
from django.contrib import messages




# Create your views here.

def user(request):
    return render(request,'index2.html',context={})
   
def signup(request):
    if request.method == 'POST':
        # un = request.POST.get("username")
        us=request.POST.get('name')
        em = request.POST.get("email")
        pas = request.POST.get("password")
        userObj=User.objects.create_user(us,em,pas)
        userObj.save()
    else:
        return render(request, "signupform.html", context={})
    return redirect("django")

def index(request):
    return render(request,'index.html')

def add(request):
    if request.method == 'POST':
        a=request.POST.get('name')
        b=request.POST.get('address')
        c=request.POST.get('studentid')
        d=request.POST.get('grade')
        e=request.POST.get('ph')
        f= Student(name=a,address=b,studentid=c,grade=d,phonenumber=e)
        f.save()
        

    else:
        return render(request,'page4.html',context={})
    return HttpResponse('Data is inserted sucessfully')
       
    
def view(request):
    emps=Student.objects.all()
    return render(request,'ll.html',context={'emps':emps})

def delete(request, eid):
    a = Student.objects.get(studentid=eid)
    a.delete()
    messages.success(request, "STUDENT Deleted successfully")
    return HttpResponse('student deleted success')

def list(request):
    emps = Student.objects.all()
    return render(request,'del.html',context={'emps':emps})


def dadd(request):
    if request.method == 'POST':
        a=request.POST.get('name')
        b=request.POST.get('studentid')
        c=request.POST.get('grade')
        e=request.POST.get('date')
        f=request.POST.get('in')
        g=request.POST.get('out')
        h= Attendence(name=a,studentid=b,grade=c,date=e,checkin=f,checkout=g)
        h.save()
    else:
        return render(request,'dadd.html',context={})
    return HttpResponse('Data is inserted sucessfully')

def dlist(request):
    dlist = Attendence.objects.all()
    return render(request,'ld.html',context={'dlist':dlist})

def dfilt(request):
    filt= Attendence.objects.filter(studentid__startswith=2)
  
    if filt:
        return render(request,'df.html',context={'filt':filt})
        #return redirect

def dfilt1(request):
    filt1= Attendence.objects.filter(studentid__startswith=1)
  
    if filt1:
        return render(request,'df2.html',context={'filt1':filt1})

    


def func2(request):
    if request.method == 'POST':
        un = request.POST.get("username")
        psw = request.POST.get("password")
        userObj=User.objects.get(username=un)
        if userObj is not None:
            user1=authenticate(request,username=un,password=psw)
            if user1 is not None:
                login(request,user1)
            else:
                return HttpResponse("Auth failed")
        else:
            return HttpResponse("No User Found")
    else:
        return render(request,"page1.html",context={})
    return redirect("ggc")
    
  






