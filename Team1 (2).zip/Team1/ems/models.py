from django.db import models

'''
# Create your models here.
class Admin(models.Model):
    username=models.CharField()
    password=models.CharField()
    edit_pass=models.CharField()



'''
class Student(models.Model):
    name=models.CharField(max_length=30)
    address=models.CharField(max_length=40,default='school')
    studentid=models.IntegerField(primary_key=True)
    grade=models.IntegerField()
    phonenumber=models.IntegerField(default=180112233)




class Attendence(models.Model):
    name=models.CharField(max_length=30)
    studentid=models.IntegerField()
    grade=models.IntegerField()
    date=models.CharField(max_length=30)
    checkin=models.CharField(max_length=30)
    checkout=models.CharField(max_length=30)

    
    
    
    
   
   


